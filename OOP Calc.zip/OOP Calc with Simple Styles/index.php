<?php require_once './pages/header.php'; ?>
 <h1>Simple Calculator with php</h1>
 <div class="form">
  <form action="./process.php" method="POST">
   <h2>Calculator Form</h2>
   <input class="input-group" type="number" name="num1" placeholder="Select First Number"><br>
   <select class="form-select" name="operators">
    <option value="add">Addition</option>
    <option value="sub">Subtraction</option>
    <option value="mul">Multiplication</option>
    <option value="div">Division</option>
    <option value="pow">Exponentiation</option>
   </select><br>
   <input class="input-group" type="number" name="num2" placeholder="Select Second Number"><br><br><br>
   <button class="btn btn-primary" type="submit">Calculate</button>
  </form>
 </div>
<?php require_once './pages/footer.php'; ?>