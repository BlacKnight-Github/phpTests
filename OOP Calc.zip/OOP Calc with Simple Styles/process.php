<?php
require_once './calc.php';

$num1 = $_POST['num1'];
$num2 = $_POST['num2'];
$operator = $_POST['operators'];

$calculator = new Calc($num1, $num2, $operator);

require_once './pages/header.php';
?>
<?php
if(empty($num1) || empty($num2)){
    ?>
    <div class="alert alert-danger">You Have an Error During The Process! ( Number Error )</div>
    <?php
}else{
    ?>
    <div class="alert alert-success">Your Progress is Done!</div>
    <?php
    echo 'The Answer is: ' . $calculator->calculate();
}
?>
<br><a class="btn btn-info" href="./index.php">Go to Calculator</a>
<?php require_once './pages/footer.php'; ?>
