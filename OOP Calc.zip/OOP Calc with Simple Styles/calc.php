<?php
class Calc{
    public $num1;
    public $num2;
    public $operator;

    public function __construct($num1, $num2, $operator){
        $this->num1 = $num1;
        $this->num2 = $num2;
        $this->operator= $operator;
    }

    public function calculate(){
        switch($this->operator){
            case 'add':
                $res = $this->num1 + $this->num2;
                break;
            case 'sub':
                $res = $res = $this->num1 - $this->num2;
                break;
            case 'mul':
                $res = $res = $this->num1 * $this->num2;
                break;
            case 'div':
                $res = $res = $this->num1 / $this->num2;
                break;
            case 'pow':
                $res = $res = $this->num1 ** $this->num2;
                break;
            default:
                echo 'Error in Operations!';
                break;
        }
        return $res;
    }
}