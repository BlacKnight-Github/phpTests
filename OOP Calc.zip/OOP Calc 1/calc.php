<?php
class Calc{
    public $num1;
    public $num2;
    public $operator;

    public function __construct($num1, $num2, $operator){
        $this->num1 = $num1;
        $this->num2 = $num2;
        $this->operator= $operator;
    }

    public function calculate(){
        switch($this->operator){
            case 'add':
                $result = $this->add();
                break;
            case 'sub':
                $result = $this->sub();
                break;
            case 'mul':
                $result = $this->mul();
                break;
            case 'div':
                $result = $this->div();
                break;
            case 'pow':
                $result = $this->pow();
                break;
            default:
                echo 'Error';
                break;
        }
        return $result;
    }

    public function add(){
        $res = $this->num1 + $this->num2;
        return $res;
    }
    public function sub(){
        $res = $this->num1 - $this->num2;
        return $res;
    }
    public function mul(){
        $res = $this->num1 * $this->num2;
        return $res;
    }
    public function div(){
        $res = $this->num1 / $this->num2;
        return $res;
    }
    public function pow(){
        $res = $this->num1 ** $this->num2;
        //or pow(x, y)
        return $res;
    }
}