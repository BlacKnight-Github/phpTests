<!DOCTYPE html>
<html lang="en-US">
 <head>
  <title>OOP Simple Calculator</title>
 </head>
 <body>
  <h1>Simple Calculator with php</h1>
  <form action="./process.php" method="POST">
   <h2>Calculator Form</h2>
   <input type="number" name="num1" placeholder="Select First Number">
   <select name="operators">
    <option value="add">Addition</option>
    <option value="sub">Subtraction</option>
    <option value="mul">Multiplication</option>
    <option value="div">Division</option>
    <option value="pow">Exponentiation</option>
   </select>
   <input type="number" name="num2" placeholder="Select Second Number">
   <button type="submit">Calculate</button>
  </form>
 </body>
</html>