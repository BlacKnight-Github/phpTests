<?php
require_once './calc.php';

$num1 = $_POST['num1'];
$num2 = $_POST['num2'];
$operator = $_POST['operators'];

$calculator = new Calc($num1, $num2, $operator);
echo 'The Answer is: '.$calculator->calculate();